var btnOpen = document.querySelector('.button__open');
var btnClose = document.querySelector('.button__close');
var menu = document.querySelector('.navigation__menu-list');
var overlay = document.querySelector('.overlay');